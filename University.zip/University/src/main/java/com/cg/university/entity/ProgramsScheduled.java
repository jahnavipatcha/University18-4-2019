package com.cg.university.entity;
import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;



@Data
@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer","handler" })
@Table(name="ProgramsScheduled")
public class ProgramsScheduled implements Serializable{
	@Id 
	@Column(name="scheduledProgramID")
	@SequenceGenerator(name="myseq",sequenceName ="program_seq", initialValue= 100, allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseq")
	private int scheduledProgramID;
	@OneToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="programName")
	private ProgramsOffered programsOffered;
	private String location;
	private String startDate;
	private String endDate;
	private String sessionPerWeek;
	
	@OneToMany(mappedBy = "programsScheduled")
	private List<Application> application;
	
	

	 
	
}
